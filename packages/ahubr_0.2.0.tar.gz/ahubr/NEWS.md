# News

This is the first release of the supplementary R package for the deployment
framework AHUB. Please find more info on: **www.github.com/qunis/ahub**
